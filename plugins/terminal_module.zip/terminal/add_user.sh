#!/bin/bash

# ===== PARAMS =====
USERNAME="$1"
PASSWORD="$2"
SUDO_NOPASSWD="${3:-yes}"

# ===== VALIDATION =====
if [ "$EUID" -ne 0 ]; then
  echo "❌ Run as root"
  exit 1
fi

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
  echo "Usage: $0 <username> <password> [yes|no]"
  exit 1
fi

# ===== CREATE OR UPDATE USER =====
if id "$USERNAME" &>/dev/null; then
  echo "ℹ️ User $USERNAME exists — updating password"
else
  useradd -m -s /bin/bash "$USERNAME"
  echo "✅ User $USERNAME created"
fi

# ===== SET / UPDATE PASSWORD =====
echo "$USERNAME:$PASSWORD" | chpasswd
echo "🔐 Password updated for $USERNAME"

# ===== SUDO ACCESS =====
SUDO_FILE="/etc/sudoers.d/$USERNAME"

if [ "$SUDO_NOPASSWD" = "yes" ]; then
  echo "$USERNAME ALL=(ALL) NOPASSWD: ALL" > "$SUDO_FILE"
  chmod 440 "$SUDO_FILE"
  echo "⚡ Full sudo access (NOPASSWD) enabled"
else
  usermod -aG wheel "$USERNAME"
  rm -f "$SUDO_FILE"
  echo "⚡ Sudo enabled (password required)"
fi

# ===== DONE =====
echo "================================="
echo "User      : $USERNAME"
echo "SSH Login : Password-based"
echo "Sudo      : $SUDO_NOPASSWD"
echo "================================="
