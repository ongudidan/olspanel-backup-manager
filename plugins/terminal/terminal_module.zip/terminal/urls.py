from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='example_index'),
    path('gui/', views.gui, name='terminal_gui'),
]
