#!/bin/bash

PHP_LIB="/etc/php/8.2"
SO_NAME="ssh2.so"
INI_FILE_PATH="/etc/php/8.2/cgi/php.ini"
HOME_PATH_FILE="/etc/olspanel/base_dir"

# Detect project dir
if [ -f "$HOME_PATH_FILE" ]; then
    PROJECT_DIR="$(cat "$HOME_PATH_FILE")"
else
    PROJECT_DIR="/usr/local/lsws/Example/html/mypanel"
fi

MODULE_DIR="$PROJECT_DIR/modules"

echo "Using project dir: $PROJECT_DIR"

# Ensure directories exist
mkdir -p "$MODULE_DIR"
mkdir -p "$PHP_LIB/modules"

# -------------------------------
# Install ssh2 PHP extension
# -------------------------------
if command -v apt >/dev/null 2>&1; then
    echo "Debian/Ubuntu detected"

    sudo apt update -y
    sudo apt install -y lsof libssh2-1 libssh2-1-dev gcc make autoconf libtool
    sudo apt install -y lsphp82-dev
	sudo apt install -y lsphp82-pear

  

elif command -v dnf >/dev/null 2>&1; then
    echo "RHEL / AlmaLinux / Rocky / Fedora detected"

    sudo dnf install -y epel-release
    sudo dnf install -y lsof libssh2 libssh2-devel gcc make autoconf libtool
    sudo dnf install -y lsphp82-devel
	sudo dnf install -y lsphp82-pear

    

fi

yes '' | /usr/local/lsws/lsphp82/bin/pecl install -f ssh2

# Find ssh2.so automatically
SSH2_SO=$(find /usr/local/lsws/lsphp82/ -name ssh2.so | head -n 1)

if [ -z "$SSH2_SO" ]; then
    echo "❌ ssh2.so not found"
    exit 1
fi

echo "Found: $SSH2_SO"

# Add extension to php.ini only once
if ! grep -q "^extension=$SSH2_SO" "$INI_FILE_PATH"; then
    echo "" >> "$INI_FILE_PATH"
    echo "extension=$SSH2_SO" >> "$INI_FILE_PATH"
    echo "✅ ssh2 extension enabled"
else
    echo "✅ ssh2 already enabled"
fi



# -------------------------------
# Install terminal module
# -------------------------------
echo "Installing terminal module"
wget -q -O "$MODULE_DIR/terminal.zip" \
"https://olspanel.com/plugin/terminal_module.zip?$(date +%s)"

unzip -oq "$MODULE_DIR/terminal.zip" -d "$MODULE_DIR"
rm -f "$MODULE_DIR/terminal.zip"

echo "✅ Terminal module installed successfully"
sudo systemctl restart cp

